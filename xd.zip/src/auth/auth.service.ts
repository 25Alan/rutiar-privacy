import { BadRequestException, Injectable } from '@nestjs/common';
import { RegisterDto } from './dto/register.dto';
import { BcryptProvider } from './bcrypt.provider';
import { InjectRepository } from '@nestjs/typeorm';
import { User } from 'src/user/user.entity';
import { Repository } from 'typeorm';
import { IRole } from 'src/user/role.enum';

@Injectable()
export class AuthService {
  constructor(
    @InjectRepository(User)
    private readonly userRepository: Repository<User>,
    private readonly bcryptProvider: BcryptProvider
  ) { }

  async register(registerDto: RegisterDto) {
    const userAlreadyExists = await this.userRepository.findOneBy({ email: registerDto.email })

    if (userAlreadyExists) throw new BadRequestException("Ya existe un usuario con ese email.")

    const hashedPassword = await this.bcryptProvider.hashPassword(registerDto.password)

    const newUser = this.userRepository.create({
      email: registerDto.email,
      birth_date: registerDto.birth_date,
      password: hashedPassword,
      roles: [{ role: IRole.USER }]
    })

    const savedUser = await this.userRepository.save(newUser)

    return { message: "Usuario creado exitosamente.", user_id: savedUser.id }
  }
}
