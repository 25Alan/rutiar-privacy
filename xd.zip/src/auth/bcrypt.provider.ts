import { Injectable } from '@nestjs/common';
import { compare, hash, genSalt } from "bcrypt"

@Injectable()
export class BcryptProvider {
  async hashPassword(password: string) {
    const SALT = await genSalt(10)
    return hash(password, SALT)
  }

  async isValidPassword(originalPassword: string, hashedPassword: string) {
    return compare(originalPassword, hashedPassword)
  }
}
