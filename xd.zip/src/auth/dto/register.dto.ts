import { IsDateString, IsEmail, IsString, MinLength } from "class-validator"

export class RegisterDto {
  @IsEmail()
  email: string

  @IsString()
  @MinLength(15)
  password: string

  @IsDateString()
  birth_date: string
}