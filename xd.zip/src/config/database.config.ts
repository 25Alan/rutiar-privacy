import { registerAs } from "@nestjs/config";
import { TypeOrmModuleOptions } from "@nestjs/typeorm";
import { resolve } from "path";

export const databaseConfiguration = registerAs<TypeOrmModuleOptions>("dbConfig", () => ({
  type: "sqlite",
  enableWAL: true,
  synchronize: true,
  entities: [],
  database: resolve("data", "dbPasantia.db")
}))