export enum IRole {
  USER,
  ASSISTANT,
  ADMIN
}