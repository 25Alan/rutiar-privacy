import { Column, ManyToOne, PrimaryGeneratedColumn } from "typeorm";
import { IRole } from "./role.enum";
import { User } from "./user.entity";

export class Role {
  @PrimaryGeneratedColumn()
  id: number

  @Column({ enum: IRole, default: IRole.USER })
  role: IRole

  @ManyToOne(() => User, (user) => user.roles)
  user: User
}