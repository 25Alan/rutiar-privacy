export async function tryOrCatch<T>(promise: Promise<T>) {
  try {
    const data = await promise;
    return [null, data] as [null, T];
  } catch (error) {
    return [error as unknown, null] as [unknown, null];
  }
}